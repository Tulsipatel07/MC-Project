import 'package:flutter/material.dart';
import 'package:flutter_demo/api_manager.dart';
import 'package:flutter_demo/category_model.dart';
import 'package:flutter_demo/products_page.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  bool isLoading = false;
  List<CategoryModel> category = [];

  @override
  void initState() {
    super.initState();
    getCategory();
  }

  getCategory() async {
    isLoading = true;
    setState(() {});
    final resposne = await ApiManager().getCall('https://api.escuelajs.co/api/v1/categories', {});

    if (resposne != null) {
      category = (resposne as List).map((e) => CategoryModel.fromJson(e)).toList();
    }

    isLoading = false;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text(
          'Dashboard',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
      ),
      body: Stack(
        children: [
          ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: category.length,
            separatorBuilder: (context, index) => const SizedBox(height: 10),
            itemBuilder: (context, index) {
              return InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ProductsPage(
                        categoryId: category[index].id ?? 0,
                      ),
                    ),
                  );
                },
                child: Container(
                  clipBehavior: Clip.hardEdge,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 1,
                        blurRadius: 5,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      Image.network(
                        category[index].image ?? '',
                        fit: BoxFit.cover,
                        height: 80,
                        width: 80,
                        errorBuilder: (context, error, stackTrace) {
                          return const SizedBox(
                            height: 80,
                            width: 80,
                          );
                        },
                      ),
                      const SizedBox(width: 10),
                      Text(
                        category[index].name ?? '',
                        style: const TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
          if (isLoading) const Center(child: CircularProgressIndicator())
        ],
      ),
    );
  }
}
